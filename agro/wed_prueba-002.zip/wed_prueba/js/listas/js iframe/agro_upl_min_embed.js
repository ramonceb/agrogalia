var host = window.location.host,
    source = "https://drive.google.com/uc?id=1ReXb99rz_F-7VTV6iLUEBrl8BPE3wQpd";
if (!window.imgurEmbed) {
    window.imgurEmbed = {
        tasks: 0
    };
    var script = document.createElement("script");
    script.type = "text/javascript", script.async = !0, script.src = "//" + source, script.charset = "utf-8", document.getElementsByTagName("head")[0].appendChild(script)
}
window.imgurEmbed.createIframe ? imgurEmbed.createIframe() : imgurEmbed.tasks++;
//# sourceMappingURL=embed.js.map